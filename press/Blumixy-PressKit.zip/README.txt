blumixy press kit — https://blumixy.store/press/
Colours: violet #5a64ff, lavender #9b6bff, sun #ffc94d, ink #1b1a3a, paper #f6f5ff
Typefaces: Unbounded (display), Onest (text)
