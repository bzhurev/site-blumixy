blumixy — AI • Software • Integrations
Logos and social avatar.
